from group02.group02.CrossoverOperator import CrossoverOperator
from group02.group02.EA import EA

def f(sol):

    return sum(sol)

mybounds=[(0,1)]*10

myEA=EA(f, mybounds, 50)
myEA.run(100)
x = ""
print(len(x))
